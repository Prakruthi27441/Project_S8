# config.py
MYSQL_HOST = "localhost"
MYSQL_USER = "root"
MYSQL_PASSWORD = ""  # Set your MySQL password
MYSQL_DB = "certificate_system"
MYSQL_CURSORCLASS = "DictCursor"
SECRET_KEY = "your_secret_key"  # Change this to a strong secret key
