from web3 import Web3
import json

# Connect to Ganache
ganache_url = "HTTP://127.0.0.1:7545"  # Change this if your Ganache runs on a different port
web3 = Web3(Web3.HTTPProvider(ganache_url))

if not web3.is_connected():
    print("Failed to connect to Ganache!")
    exit()

# Load compiled contract
with open("compiled_contract.json", "r") as file:
    compiled_contract = json.load(file)

# Extract ABI and Bytecode
contract_abi = compiled_contract["contracts"]["CertificateRegistry.sol"]["CertificateRegistry"]["abi"]
contract_bytecode = compiled_contract["contracts"]["CertificateRegistry.sol"]["CertificateRegistry"]["evm"]["bytecode"]["object"]

# Get the first Ganache account (admin account for deployment)
deployer_account = web3.eth.accounts[0]
web3.eth.default_account = deployer_account

# Deploy the contract
CertificateRegistry = web3.eth.contract(abi=contract_abi, bytecode=contract_bytecode)
tx_hash = CertificateRegistry.constructor().transact()
tx_receipt = web3.eth.wait_for_transaction_receipt(tx_hash)

contract_address = tx_receipt.contractAddress
print(f"Contract deployed successfully at: {contract_address}")

# Save contract address for future use
with open("contract_address.txt", "w") as file:
    file.write(contract_address)
